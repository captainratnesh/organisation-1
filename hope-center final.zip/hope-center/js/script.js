$(document).ready(function() {		
		// tool tip
	$('.normaltip').aToolTip({
    	toolTipClass: 'aToolTip'});

})
